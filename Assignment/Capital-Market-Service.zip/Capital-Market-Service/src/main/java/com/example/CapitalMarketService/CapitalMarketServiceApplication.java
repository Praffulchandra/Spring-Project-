package com.example.CapitalMarketService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapitalMarketServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapitalMarketServiceApplication.class, args);
	}

}
