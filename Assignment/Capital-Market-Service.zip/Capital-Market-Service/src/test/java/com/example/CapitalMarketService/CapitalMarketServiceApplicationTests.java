package com.example.CapitalMarketService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapitalMarketServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
